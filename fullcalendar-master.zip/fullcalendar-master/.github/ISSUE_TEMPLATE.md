WARNING!!!

> Please back up and follow the issue template for a BUG or a FEATURE!!!
> If you do not, your issue is very likely to be automatically closed!!!

ESCAPE HATCH:

> If your issue is neither a bug nor a feature, include the text "I love FullCalendar".
> This will ensure your issue is not automatically closed.
