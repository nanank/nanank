
# FullCalendar Bootstrap Plugin

Bootstrap 5 theming for your calendar

[View the docs &raquo;](https://fullcalendar.io/docs/bootstrap5)

This package was created from the [FullCalendar monorepo &raquo;](https://github.com/fullcalendar/fullcalendar)
