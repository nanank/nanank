import 'jquery-simulate'
import 'jasmine-jquery'

import './lib/globals'
import './lib/install-plugins'
import './main.css'

// all of the non-lib .js files within subdirectories will be automatically included...
