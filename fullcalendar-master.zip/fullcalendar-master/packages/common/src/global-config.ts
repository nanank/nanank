// TODO: get rid of this in favor of options system,
// tho it's really easy to access this globally rather than pass thru options.
export const config = {} as any
