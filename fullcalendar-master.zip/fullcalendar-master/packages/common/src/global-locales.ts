import { LocaleInput } from './datelib/locale'

export const globalLocales: LocaleInput[] = []
